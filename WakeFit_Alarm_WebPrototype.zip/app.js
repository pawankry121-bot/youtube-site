const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let alarms=JSON.parse(localStorage.getItem("wakefit_alarms")||"[]");
let zones=JSON.parse(localStorage.getItem("wakefit_zones")||'["Asia/Kolkata"]');
let editId=null, ringingAlarm=null, missionCount=0, missionTarget=10, cameraStream=null;
const missions={pushups:["💪","Push-ups"],squats:["🏋️","Squats"],steps:["🏃","Steps"],jumping:["🤸","Jumping Jacks"],plank:["🧘","Plank"],math:["🧠","Math Challenge"],random:["🎲","Daily Random"]};

function save(){localStorage.setItem("wakefit_alarms",JSON.stringify(alarms));renderAlarms()}
function formatTime(d){return d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"})}
function updateClock(){
  const d=new Date(); $("#currentTime").textContent=formatTime(d);
  checkAlarms(d); renderWorldClocks();
}
setInterval(updateClock,1000); updateClock();

function dayText(days){return days.length===7?"Every day":days.length===5&&[1,2,3,4,5].every(x=>days.includes(x))?"Mon–Fri":days.length===2&&days.includes(0)&&days.includes(6)?"Sat–Sun":days.map(x=>["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][x]).join(" ")}
function missionText(a){
  let m=a.mission==="random"?missions[["pushups","squats","steps","jumping","plank"][new Date().getDay()%5]]:missions[a.mission];
  return `${m[0]} ${a.target} ${m[1]}`;
}
function renderAlarms(){
  const list=$("#alarmList"); list.innerHTML="";
  if(!alarms.length){$("#emptyState").classList.remove("hidden");return} $("#emptyState").classList.add("hidden");
  alarms.forEach(a=>{
    const div=document.createElement("div");div.className="alarm-card";
    div.innerHTML=`<div><div class="alarm-time">${a.time}</div><div class="alarm-sub">${dayText(a.days)} · ${escapeHtml(a.label||"Wake up")}</div><div class="mission-preview">${missionText(a)}</div></div>
    <div class="card-actions"><button class="small-btn edit">✎</button><button class="small-btn del">🗑</button><button class="toggle ${a.enabled?"on":""}" aria-label="toggle"><i></i></button></div>`;
    div.querySelector(".edit").onclick=()=>openAlarm(a.id);
    div.querySelector(".del").onclick=()=>{alarms=alarms.filter(x=>x.id!==a.id);save()};
    div.querySelector(".toggle").onclick=()=>{a.enabled=!a.enabled;save()};
    list.appendChild(div);
  });
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}

const dayNames=["S","M","T","W","T","F","S"];
function setupDays(selected=[]){$("#dayPicker").innerHTML="";dayNames.forEach((n,i)=>{let b=document.createElement("button");b.className="day "+(selected.includes(i)?"selected":"");b.textContent=n;b.onclick=()=>b.classList.toggle("selected");$("#dayPicker").appendChild(b)})}
function openAlarm(id=null){
  editId=id; const a=id?alarms.find(x=>x.id===id):null;
  $("#modalTitle").textContent=a?"Edit Alarm":"New Alarm"; $("#alarmTime").value=a?.time||"06:00";$("#alarmLabel").value=a?.label||"Wake up";
  $("#missionType").value=a?.mission||"random";$("#difficulty").value=a?.difficulty||"medium";$("#strictMission").checked=a?.strict!==false;$("#alarmVibration").checked=a?.vibration!==false;
  setupDays(a?.days||[1,2,3,4,5]);$("#alarmModal").classList.remove("hidden");
}
function closeAlarm(){$("#alarmModal").classList.add("hidden");editId=null}
$("#addAlarmBtn").onclick=()=>openAlarm();$("#settingsBtn").onclick=()=>showPage("settingsPage");$("#closeModal").onclick=closeAlarm;$("#cancelAlarm").onclick=closeAlarm;
$("#saveAlarm").onclick=()=>{
  const days=[...$("#dayPicker").children].map((b,i)=>b.classList.contains("selected")?i:null).filter(x=>x!==null);
  if(!$("#alarmTime").value||!days.length){alert("Select a time and at least one day.");return}
  const a={id:editId||crypto.randomUUID(),time:$("#alarmTime").value,label:$("#alarmLabel").value||"Wake up",days,mission:$("#missionType").value,difficulty:$("#difficulty").value,strict:$("#strictMission").checked,vibration:$("#alarmVibration").checked,enabled:true,target:targetFor($("#missionType").value,$("#difficulty").value)};
  if(editId) alarms=alarms.map(x=>x.id===editId?a:x);else alarms.push(a);save();closeAlarm();
}
function targetFor(m,d){if(m==="plank")return d==="easy"?10:d==="hard"?30:20;if(m==="steps")return d==="easy"?100:d==="hard"?1000:500;if(m==="math")return 1;return d==="easy"?5:d==="hard"?15:10}

let lastTriggerKey="";
function checkAlarms(d){
  const hh=String(d.getHours()).padStart(2,"0"),mm=String(d.getMinutes()).padStart(2,"0"),key=`${d.toDateString()}-${hh}:${mm}`;
  if(key===lastTriggerKey)return;
  alarms.forEach(a=>{
    if(!a.enabled||a.time!==`${hh}:${mm}`||!a.days.includes(d.getDay()))return;
    lastTriggerKey=key; startRing(a);
  });
}
function startRing(a){
  ringingAlarm=a;missionCount=0;missionTarget=a.target;$("#ringTime").textContent=a.time;$("#ringLabel").textContent=(a.label||"GOOD MORNING!").toUpperCase();
  $("#ringMission").textContent=missionText(a);$("#missionProgress").style.width="0%";$("#missionCounter").textContent=`0 / ${missionTarget}`;
  $("#missionInstruction").textContent="Complete the mission to dismiss the alarm.";
  $("#ringModal").classList.remove("hidden"); $("#missionActionBtn").classList.remove("hidden"); $("#startCameraBtn").classList.remove("hidden");
  if(a.vibration&&navigator.vibrate)navigator.vibrate([700,400,700,400,1000]);
  playBeep();
}
function playBeep(){
  try{const ctx=new (window.AudioContext||window.webkitAudioContext)();let o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=880;o.connect(g);g.connect(ctx.destination);g.gain.value=.12;o.start();setTimeout(()=>{o.stop();ctx.close()},700)}catch(e){}
}
$("#missionActionBtn").onclick=()=>{
  if(!ringingAlarm)return;
  missionCount++; if(ringingAlarm.mission==="math"){missionCount=missionTarget}
  const pct=Math.min(100,missionCount/missionTarget*100);$("#missionProgress").style.width=pct+"%";$("#missionCounter").textContent=`${missionCount} / ${missionTarget}`;
  if(missionCount>=missionTarget){$("#missionInstruction").textContent="🎉 Mission complete! You can stop the alarm now.";$("#missionActionBtn").textContent="Stop Alarm";$("#missionActionBtn").onclick=stopRing}
};
$("#startCameraBtn").onclick=async()=>{
  try{cameraStream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});$("#cameraVideo").srcObject=cameraStream;$("#cameraWrap").classList.remove("hidden");$("#startCameraBtn").textContent="Camera Active";$("#startCameraBtn").disabled=true}
  catch(e){alert("Camera permission was denied or unavailable. You can use the fallback mission counter in this prototype.")}
};
function stopRing(){if(!ringingAlarm)return; if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null}$("#ringModal").classList.add("hidden");ringingAlarm=null;$("#missionActionBtn").onclick=null;$("#missionActionBtn").textContent="Complete 1 Rep";if(navigator.vibrate)navigator.vibrate(0)}
$("#emergencyStopBtn").onclick=()=>{if(confirm("Emergency stop the alarm?"))stopRing()};

function showPage(id){
  $$(".page").forEach(p=>p.classList.remove("active"));$("#"+id).classList.add("active");
  $$(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===id));
}
$$(".nav-btn").forEach(b=>b.onclick=()=>showPage(b.dataset.page));

function renderWorldClocks(){
  const list=$("#clockList");list.innerHTML="";
  zones.forEach(z=>{let d=new Date();let time=d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit",timeZone:z});let name=z.split("/").pop().replaceAll("_"," ");let x=document.createElement("div");x.className="clock-item";x.innerHTML=`<div><b>${name}</b><div class="alarm-sub">${z}</div></div><strong>${time}</strong>`;list.appendChild(x)})
}
$("#addZoneBtn").onclick=()=>{let z=$("#zoneSelect").value;if(!zones.includes(z))zones.push(z);localStorage.setItem("wakefit_zones",JSON.stringify(zones));renderWorldClocks()};

let swStart=0,swElapsed=0,swRun=false,swInt=null;
function swRender(){let t=swRun?performance.now()-swStart+swElapsed:swElapsed;let cs=Math.floor(t/10)%100,s=Math.floor(t/1000)%60,m=Math.floor(t/60000);$("#stopwatchDisplay").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(cs).padStart(2,"0")}`}
$("#startStopwatchBtn").onclick=()=>{if(!swRun){swStart=performance.now();swRun=true;$("#startStopwatchBtn").textContent="Pause";swInt=setInterval(swRender,40)}else{swElapsed+=performance.now()-swStart;swRun=false;clearInterval(swInt);$("#startStopwatchBtn").textContent="Start";swRender()}};
$("#resetStopwatchBtn").onclick=()=>{swRun=false;clearInterval(swInt);swElapsed=0;$("#startStopwatchBtn").textContent="Start";$("#laps").innerHTML="";swRender()};
$("#lapBtn").onclick=()=>{if(!swRun)return;let p=document.createElement("div");p.textContent=$("#stopwatchDisplay").textContent;$("#laps").prepend(p)};

let timerEnd=0,timerRemain=0,timerRun=false,timerInt=null;
function timerRender(){let r=timerRun?Math.max(0,timerEnd-Date.now()):timerRemain;timerRemain=r;let s=Math.ceil(r/1000),m=Math.floor(s/60);s%=60;$("#timerDisplay").textContent=`${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;if(r<=0&&timerRun){timerRun=false;clearInterval(timerInt);playBeep();$("#startTimerBtn").textContent="Start"}}
$("#startTimerBtn").onclick=()=>{if(!timerRun){if(!timerRemain){timerRemain=(+$("#timerMin").value||0)*60000+(+$("#timerSec").value||0)*1000}if(timerRemain<=0)return;timerEnd=Date.now()+timerRemain;timerRun=true;$("#startTimerBtn").textContent="Pause";timerInt=setInterval(timerRender,200)}else{timerRemain=Math.max(0,timerEnd-Date.now());timerRun=false;clearInterval(timerInt);$("#startTimerBtn").textContent="Start";timerRender()}};
$("#resetTimerBtn").onclick=()=>{timerRun=false;clearInterval(timerInt);timerRemain=0;$("#startTimerBtn").textContent="Start";timerRender()};

$("#themeSelect").onchange=e=>{document.body.classList.toggle("light",e.target.value==="light");localStorage.setItem("wakefit_theme",e.target.value)};
$$(".accent").forEach(b=>b.onclick=()=>{let a=b.dataset.accent;let map={purple:"#8b5cf6",blue:"#2563eb",cyan:"#06b6d4",pink:"#ec4899"};document.documentElement.style.setProperty("--accent",map[a]);localStorage.setItem("wakefit_accent",a)});
(function init(){let t=localStorage.getItem("wakefit_theme")||"system";$("#themeSelect").value=t;if(t==="light")document.body.classList.add("light");renderAlarms();renderWorldClocks();swRender();timerRender();})();
